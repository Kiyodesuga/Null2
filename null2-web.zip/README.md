# NULL² Web

このプロジェクトはFlutterでビルドされたWeb版のNULL²体験版です。

## デプロイ方法（Vercel）
1. このリポジトリをVercelにインポート
2. `vercel.json` のルーティングにより404を回避
3. `build/web` フォルダが公開対象